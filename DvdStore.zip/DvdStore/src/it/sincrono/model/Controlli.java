package it.sincrono.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Controlli 
{
	
	
	
	public boolean check(String username,String password) 
	{
		
		boolean d=false;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila?user=root&password=root");
			Statement t=c.createStatement();
			ResultSet r=t.executeQuery("SELECT first_name FROM actor WHERE first_name='"+username+"' AND last_name='"+password+"'");
			
			if(r.first()) {
				d=true;
			}
			
			
			
		    
		} 
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
		
		
		
		
	}
	
	public Actor findById(int id) {
		
		Actor a=new Actor();
		
		String q="select * from actor where actor_id="+id;
		
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila?user=root&password=root");
			Statement t=c.createStatement();
			ResultSet r=t.executeQuery(q);
			
			if(r.first()) {
				
				a.setId(  r.getInt("actor_id")     );
				a.setCognome(   r.getString("last_name")    );
				a.setNome(    r.getString("first_name")   );
			}
			
			
			
		} 
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return a;
		
		
	}
	
	

}
