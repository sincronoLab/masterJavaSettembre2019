package org.andrea.myexample.myAutowiringByName;

// Classe dipendente che rappresenta il correttore ortografico:
public class SpellChecker {

	// Costruttore:
	public SpellChecker() {
		System.out.println("Inside SpellChecker constructor.");
	}

	// Esegue la correzione ortografica:
	public void checkSpelling() {
		System.out.println("Inside checkSpelling.");
	}

}