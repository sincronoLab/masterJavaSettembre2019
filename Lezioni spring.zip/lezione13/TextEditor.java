package org.corso.myexample.myAutowiringByName;

// Classe che rappresenta un editor di testo:
public class TextEditor {

	// Correttore ortografico:
	private SpellChecker spellChecker;
	private String name;

	// Metodo Setter per iniettare il correttore ortografico:
	public void setSpellChecker(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}

	public SpellChecker getSpellChecker() {
		return spellChecker;
	}

	// Metodo Setter per inietare la stringa name
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	// Metodo che esegue la correzione ortografica
	public void spellCheck() {
		spellChecker.checkSpelling();
	}
}